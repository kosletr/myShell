# example batch file

echo 

&&pwd && date

echo 

pwd; date

echo 

date;;;; pwd

echo 

grep hello file1 && date

echo 

pw ; date

echo 

dat && pwd

echo 

ls -a|wc -c 
